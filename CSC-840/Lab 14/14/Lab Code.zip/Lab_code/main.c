/* 
 * This program demonstrates the importance of minimization 
 * in terms of network footprint, privilege elevation
 *
 * This program does the following:
 * 1. It binds to port 80. To bind to port 80 it invokes setuid() 
 *    so that it gets the privilege of file owner(root)
 * 2. It listens on port 80 and waits to receive a string which it
 *    it interprets as a directory path
 * 3. It executes ls <directory_path> and sends back the response to
 *    client.
 *
 * This program is intentionally left vulnerable to privileged command 
 * execution.
 *
 */
#include <stdio.h>
#include <netdb.h>
#include <netinet/in.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <dlfcn.h>

#define PORT 80

#define SA struct sockaddr

void create_http_server() {
        char buf[512], cmd[520], result[512];
        FILE *pipe = NULL;
        int sockfd, connfd, len;
        struct sockaddr_in servaddr, cli;
        int rid;

        sockfd = socket(AF_INET, SOCK_STREAM, 0);
        if (sockfd == -1) {
                printf("socket creation failed...\n");
                exit(0);
        }
        bzero(&servaddr, sizeof(servaddr));

        servaddr.sin_family = AF_INET;
        servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
        servaddr.sin_port = htons(PORT);
        rid = getuid();

        /* switch to the superuser */
        if (setuid(0)) {
                perror("setuid failed");
        }

        /* bind to port 80 */
        if ((bind(sockfd, (SA*)&servaddr, sizeof(servaddr))) != 0) {
                printf("socket bind failed...\n");
                exit(0);
        }
        if ((listen(sockfd, 5)) != 0) {
                printf("Listen failed...\n");
                exit(0);
        }
        else {
                printf("Server listening on port# 8080\n");
        }
        len = sizeof(cli);

        while (1) {
                int ret=1;
                connfd = accept(sockfd, (SA*)&cli, &len);
                if (connfd < 0) {
                        printf("server accept failed...\n");
                        exit(0);
                }
                else {
                        printf("recvd connection at port# 8080\n");
                }
                while (ret > 0) {
                        /* read the directory path string */
                        ret = read(connfd, buf, 512);
                        strncpy(cmd, "ls ", 512);
                        strncat(cmd, buf, 512);

                        /* execute ls <directory_path> */
                        pipe = popen(cmd, "r");
                        if (!pipe) {
                                printf("popen failed");
                                exit(0);
                        }

                        while (!feof(pipe)) {
                                if (fgets(buf, 128, pipe) != NULL)
                                        strncat(result, buf, 512);
                        }
                        pclose(pipe);
                        write(connfd, result, 512);
                }
                close(connfd);
        }

        close(sockfd);
}


int main() {
        create_http_server();
}

